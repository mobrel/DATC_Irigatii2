using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Google.Maps;
using Google.Maps.Geocoding;
using Google.Maps.StaticMaps;

// This is the code for your desktop app.
// Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.

namespace ma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Click on the link below to continue learning how to build a desktop app using WinForms!
            System.Diagnostics.Process.Start("http://aka.ms/dotnet-get-started-desktop");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thanks!");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            README_QuickStart_Sample1();
            DoRequestsLoop();
        }

        public void README_QuickStart_Sample1()
        {
            //always need to use YOUR_API_KEY for requests.  Do this in App_Start.
            GoogleSigned.AssignAllServices(new GoogleSigned("AIzaSyCl5fGV5DZvWu509u8EcVBFgI-Ik3ttNb4"));

            var request = new GeocodingRequest();
            request.Address = "Tebea";
            var response = new GeocodingService().GetResponse(request);

            //The GeocodingService class submits the request to the API web service, and returns the
            //response strongly typed as a GeocodeResponse object which may contain zero, one or more results.

            //Assuming we received at least one result, let's get some of its properties:
            if (response.Status == ServiceResponseStatus.Ok && response.Results.Count() > 0)
            {
                var result = response.Results.First();

                Console.WriteLine("Full Address: " + result.FormattedAddress);         // "1600 Pennsylvania Ave NW, Washington, DC 20500, USA"
                Console.WriteLine("Latitude: " + result.Geometry.Location.Latitude);   // 38.8976633
                Console.WriteLine("Longitude: " + result.Geometry.Location.Longitude); // -77.0365739
                Console.WriteLine();
                label1.Text = "Full Address: " + result.FormattedAddress;
                
                refreshMap(result.Geometry.Location);
            }
            else
            {
                Console.WriteLine("Unable to geocode.  Status={0} and ErrorMessage={1}", response.Status, response.ErrorMessage);
            }

        }

        static void DoRequestsLoop()
        {
            Dictionary<string, Action> menuchoice = new Dictionary<string, Action>(StringComparer.OrdinalIgnoreCase);

            menuchoice.Add("G", DoGeocodeRequest);
            //menuchoice.Add("Q", null);

            ConsoleKeyInfo keypress;
            do
            {
                Console.WriteLine("Menu\n--------");
                Console.WriteLine("G)eocode request");
                Console.WriteLine("Q)uit");

                keypress = Console.ReadKey(); Console.WriteLine();
                var key = keypress.KeyChar.ToString();

                Action actionfunc = null;
                if (menuchoice.ContainsKey(key) == true)
                {
                    actionfunc = menuchoice[key];
                    if (actionfunc != null) actionfunc();
                }

            } while (keypress.Key != ConsoleKey.Q);
        }

        private void refreshMap(Location location)
        {
            var request = new StaticMapRequest
            {
                Center = location
                ,
                Zoom = 100
                ,
                Size = new MapSize(100,100)
                ,
                MapType = (MapTypes)Enum.Parse(typeof(MapTypes), "roadmap", true)
            };
            request.Markers.Add(request.Center);

            var mapSvc = new StaticMapService();
            var imageSource = new BitmapImage();
            imageSource.BeginInit();
            imageSource.StreamSource = mapSvc.GetStream(request);
            imageSource.CacheOption = BitmapCacheOption.OnLoad;
            imageSource.EndInit();
           
            pictureBox1.Image = System.Drawing.Image.FromStream(mapSvc.GetStream(request));
        }
        static void DoGeocodeRequest()
        {
            //always need to use YOUR_API_KEY for requests.  Do this in App_Start.
            //GoogleSigned.AssignAllServices(new GoogleSigned("YOUR_API_KEY"));
            //commented out in the loop

            Console.WriteLine();
            Console.WriteLine("Enter an address to geocode: ");
            string geocodeAddress = Console.ReadLine();

            var request = new GeocodingRequest();
            request.Address = geocodeAddress;
            var response = new GeocodingService().GetResponse(request);

            //The GeocodingService class submits the request to the API web service, and returns the
            //response strongly typed as a GeocodeResponse object which may contain zero, one or more results.

            //Assuming we received at least one result, let's get some of its properties:
            if (response.Status == ServiceResponseStatus.Ok && response.Results.Count() > 0)
            {
                var result = response.Results.First();

                Console.WriteLine("Full Address: " + result.FormattedAddress);         // "1600 Pennsylvania Ave NW, Washington, DC 20500, USA"
                Console.WriteLine("Latitude: " + result.Geometry.Location.Latitude);   // 38.8976633
                Console.WriteLine("Longitude: " + result.Geometry.Location.Longitude); // -77.0365739
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Unable to geocode.  Status={0} and ErrorMessage={1}", response.Status, response.ErrorMessage);
            }
        }
    }
}
