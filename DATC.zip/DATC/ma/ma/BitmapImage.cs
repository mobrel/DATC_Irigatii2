﻿#region Assembly PresentationCore, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.6.1\PresentationCore.dll
#endregion

using System.ComponentModel;
using System.IO;
using System.Net.Cache;
using System.Windows.Markup;

namespace System.Windows.Media.Imaging
{
    //
    // Summary:
    //     Provides a specialized System.Windows.Media.Imaging.BitmapSource that is optimized
    //     for loading images using Extensible Application Markup Language (XAML).
    public sealed class BitmapImage : BitmapSource, ISupportInitialize, IUriContext
    {
        //
        // Summary:
        //     Identifies the System.Windows.Media.Imaging.BitmapImage.UriCachePolicy dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.Media.Imaging.BitmapImage.UriCachePolicy
        //     dependency property.
        public static readonly DependencyProperty UriCachePolicyProperty;
        //
        // Summary:
        //     Identifies the System.Windows.Media.Imaging.BitmapImage.UriSource dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.Media.Imaging.BitmapImage.UriSource dependency
        //     property.
        public static readonly DependencyProperty UriSourceProperty;
        //
        // Summary:
        //     Identifies the System.Windows.Media.Imaging.BitmapImage.StreamSource dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.Media.Imaging.BitmapImage.StreamSource
        //     dependency property.
        public static readonly DependencyProperty StreamSourceProperty;
        //
        // Summary:
        //     Identifies the System.Windows.Media.Imaging.BitmapImage.DecodePixelWidth dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.Media.Imaging.BitmapImage.DecodePixelWidth
        //     dependency property.
        public static readonly DependencyProperty DecodePixelWidthProperty;
        //
        // Summary:
        //     Identifies the System.Windows.Media.Imaging.BitmapImage.DecodePixelHeight dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.Media.Imaging.BitmapImage.DecodePixelHeight
        //     dependency property.
        public static readonly DependencyProperty DecodePixelHeightProperty;
        //
        // Summary:
        //     Identifies the System.Windows.Media.Imaging.BitmapImage.Rotation dependency property.
        //
        // Returns:
        //     The identifier for the System.Windows.Media.Imaging.BitmapImage.Rotation dependency
        //     property.
        public static readonly DependencyProperty RotationProperty;
        //
        // Summary:
        //     Identifies the System.Windows.Media.Imaging.BitmapImage.SourceRect dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.Media.Imaging.BitmapImage.SourceRect dependency
        //     property.
        public static readonly DependencyProperty SourceRectProperty;
        //
        // Summary:
        //     Identifies the System.Windows.Media.Imaging.BitmapImage.CreateOptions dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.Media.Imaging.BitmapImage.CreateOptions
        //     dependency property.
        public static readonly DependencyProperty CreateOptionsProperty;
        //
        // Summary:
        //     Identifies the System.Windows.Media.Imaging.BitmapImage.CacheOption dependency
        //     property.
        //
        // Returns:
        //     The identifier for the System.Windows.Media.Imaging.BitmapImage.CacheOption dependency
        //     property.
        public static readonly DependencyProperty CacheOptionProperty;

        //
        // Summary:
        //     Initializes a new instance of the System.Windows.Media.Imaging.BitmapImage class.
        public BitmapImage();
        //
        // Summary:
        //     Initializes a new instance of the System.Windows.Media.Imaging.BitmapImage class
        //     by using the supplied System.Uri.
        //
        // Parameters:
        //   uriSource:
        //     The System.Uri to use as the source of the System.Windows.Media.Imaging.BitmapImage.
        //
        // Exceptions:
        //   T:System.ArgumentNullException:
        //     The uriSource parameter is null.
        //
        //   T:System.IO.FileNotFoundException:
        //     The file specified by the uriSource parameter is not found.
        public BitmapImage(Uri uriSource);
        //
        // Summary:
        //     Initializes a new instance of the System.Windows.Media.Imaging.BitmapImage class
        //     with an image whose source is a System.Uri, and is cached according to the provided
        //     System.Net.Cache.RequestCachePolicy.
        //
        // Parameters:
        //   uriSource:
        //     The System.Uri to use as the source of the System.Windows.Media.Imaging.BitmapImage.
        //
        //   uriCachePolicy:
        //     The System.Net.Cache.RequestCachePolicy that specifies the caching requirements
        //     for images that are obtained using HTTP.
        //
        // Exceptions:
        //   T:System.ArgumentNullException:
        //     The uriSource parameter is null.
        //
        //   T:System.IO.FileNotFoundException:
        //     The file specified by the uriSource parameter is not found.
        public BitmapImage(Uri uriSource, RequestCachePolicy uriCachePolicy);

        //
        // Summary:
        //     Gets or sets the rectangle that is used as the source of the System.Windows.Media.Imaging.BitmapImage.
        //
        // Returns:
        //     The rectangle that is used as the source of the System.Windows.Media.Imaging.BitmapImage.
        //     The default is System.Windows.Int32Rect.Empty.
        public Int32Rect SourceRect { get; set; }
        //
        // Summary:
        //     Gets or sets the angle that this System.Windows.Media.Imaging.BitmapImage is
        //     rotated to.
        //
        // Returns:
        //     The rotation that is used for the System.Windows.Media.Imaging.BitmapImage. The
        //     default is System.Windows.Media.Imaging.Rotation.Rotate0.
        public Rotation Rotation { get; set; }
        //
        // Summary:
        //     Gets or sets the height, in pixels, that the image is decoded to.
        //
        // Returns:
        //     The height, in pixels, that the image is decoded to. The default value is 0.
        public int DecodePixelHeight { get; set; }
        //
        // Summary:
        //     Gets or sets the width, in pixels, that the image is decoded to.
        //
        // Returns:
        //     The width, in pixels, that the image is decoded to. The default value is 0.
        public int DecodePixelWidth { get; set; }
        //
        // Summary:
        //     Gets or sets the stream source of the System.Windows.Media.Imaging.BitmapImage.
        //
        // Returns:
        //     The stream source of the System.Windows.Media.Imaging.BitmapImage. The default
        //     is null.
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Stream StreamSource { get; set; }
        //
        // Summary:
        //     Gets or sets the System.Uri source of the System.Windows.Media.Imaging.BitmapImage.
        //
        // Returns:
        //     The System.Uri source of the System.Windows.Media.Imaging.BitmapImage. The default
        //     is null.
        public Uri UriSource { get; set; }
        //
        // Summary:
        //     Gets or sets a value that represents the caching policy for images that come
        //     from an HTTP source.
        //
        // Returns:
        //     The base System.Net.Cache.RequestCachePolicy of the current context. The default
        //     is null.
        [TypeConverter(typeof(RequestCachePolicyConverter))]
        public RequestCachePolicy UriCachePolicy { get; set; }
        //
        // Summary:
        //     Not supported. System.Windows.Media.Imaging.BitmapImage does not support the
        //     System.Windows.Media.Imaging.BitmapImage.Metadata property and will throw a System.NotSupportedException.
        //
        // Returns:
        //     Not supported.
        //
        // Exceptions:
        //   T:System.NotSupportedException:
        //     An attempt to read the System.Windows.Media.Imaging.BitmapImage.Metadata occurs.
        public override ImageMetadata Metadata { get; }
        //
        // Summary:
        //     Gets a value that indicates whether the System.Windows.Media.Imaging.BitmapImage
        //     is currently downloading content.
        //
        // Returns:
        //     true if the System.Windows.Media.Imaging.BitmapImage is downloading content;
        //     otherwise, false.
        public override bool IsDownloading { get; }
        //
        // Summary:
        //     Gets or sets the System.Windows.Media.Imaging.BitmapCacheOption to use for this
        //     instance of System.Windows.Media.Imaging.BitmapImage.
        //
        // Returns:
        //     The System.Windows.Media.Imaging.BitmapCacheOption being used for the System.Windows.Media.Imaging.BitmapImage.
        //     The default is System.Windows.Media.Imaging.BitmapCacheOption.Default.
        public BitmapCacheOption CacheOption { get; set; }
        //
        // Summary:
        //     Gets or sets the System.Windows.Media.Imaging.BitmapCreateOptions for a System.Windows.Media.Imaging.BitmapImage.
        //
        // Returns:
        //     The System.Windows.Media.Imaging.BitmapCreateOptions used for this System.Windows.Media.Imaging.BitmapImage.
        //     The default is System.Windows.Media.Imaging.BitmapCreateOptions.None.
        public BitmapCreateOptions CreateOptions { get; set; }
        //
        // Summary:
        //     Gets or sets a value that represents the base System.Uri of the current System.Windows.Media.Imaging.BitmapImage
        //     context.
        //
        // Returns:
        //     The base System.Uri of the current context.
        public Uri BaseUri { get; set; }

        //
        // Summary:
        //     Signals the start of the System.Windows.Media.Imaging.BitmapImage initialization.
        //
        // Exceptions:
        //   T:System.InvalidOperationException:
        //     The System.Windows.Media.Imaging.BitmapImage is currently being initialized.
        //     System.Windows.Media.Imaging.BitmapImage.BeginInit has already been called.-or-The
        //     System.Windows.Media.Imaging.BitmapImage has already been initialized.
        public void BeginInit();
        //
        // Summary:
        //     Creates a modifiable clone of this System.Windows.Media.Imaging.BitmapImage,
        //     making deep copies of this object's values.
        //
        // Returns:
        //     A modifiable clone of the current object. The cloned object's System.Windows.Freezable.IsFrozen
        //     property is false even if the source's System.Windows.Freezable.IsFrozen property
        //     is true.
        public BitmapImage Clone();
        //
        // Summary:
        //     Creates a modifiable clone of this System.Windows.Media.Imaging.BitmapImage object,
        //     making deep copies of this object's current values. Resource references, data
        //     bindings, and animations are not copied, but their current values are.
        //
        // Returns:
        //     A modifiable clone of the current object. The cloned object's System.Windows.Freezable.IsFrozen
        //     property is false even if the source's System.Windows.Freezable.IsFrozen property
        //     is true.
        public BitmapImage CloneCurrentValue();
        //
        // Summary:
        //     Signals the end of the System.Windows.Media.Imaging.BitmapImage initialization.
        //
        // Exceptions:
        //   T:System.InvalidOperationException:
        //     The System.Windows.Media.Imaging.BitmapImage.UriSource or System.Windows.Media.Imaging.BitmapImage.StreamSource
        //     properties are null.-or-The System.Windows.Media.Imaging.BitmapImage.EndInit
        //     method is called without first calling System.Windows.Media.Imaging.BitmapImage.BeginInit.
        public void EndInit();
        protected override void CloneCore(Freezable source);
        protected override void CloneCurrentValueCore(Freezable source);
        protected override Freezable CreateInstanceCore();
        protected override void GetAsFrozenCore(Freezable source);
        protected override void GetCurrentValueAsFrozenCore(Freezable source);
    }
}